TOWR - Trajectory Optimizer for Walking Robots {#mainpage}
=================
*A light-weight and extensible C++ library for trajectory optimization for legged robots.* 

For an overview, see <a href="https://github.com/ethz-adrl/towr/blob/master/README.md">
Github's README.md
</a>.

\image html towr_motion_snaps.png





